package ru.startandroid.develop.petstore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class OrderSearch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_search);
    }

    public void goStore(View v)
    {
        Intent intent = new Intent(this, StoreActivity.class);
        startActivity(intent);
        finish();
    }
    public void goMenu(View v)
    {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
        finish();
    }

    public void orderInfo(View v)
    {
        TextView name = findViewById(R.id.orderTV);
        EditText etid = findViewById(R.id.petID);
        String path = String.valueOf(etid.getText());

        if (Integer.parseInt(String.valueOf(etid.getText())) > 10) {
            name.setText("ID must be under 10");
        } else {

            Gson gson = new GsonBuilder()
                    .setLenient()
                    .create();
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("https://petstore.swagger.io/v2/")
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
            JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);

            Call<Order> call = jsonPlaceHolderApi.getOrder(path);

            call.enqueue(new Callback<Order>() {
                @Override
                public void onResponse(Call<Order> call, Response<Order> response) {
                    if (!response.isSuccessful()) {
                        name.setText(String.valueOf(response.code()));
                        return;
                    }

                    Order order = response.body();

                    String content = "";
                    content += "Pet ID: " + String.valueOf(order.getPetId())
                            + "\nquantity: " + String.valueOf(order.getQuantity())
                            + "\nShip date: " + String.valueOf(order.getShipDate())
                            + "\nStatus: " + String.valueOf(order.getStatus());

                    name.setText(content);

                }

                @Override
                public void onFailure(Call<Order> call, Throwable t) {
                    name.setText("errror" + t.getMessage());
                }
            });
        }
    }
}